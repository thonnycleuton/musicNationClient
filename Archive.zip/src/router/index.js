import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

import Artista from '@/components/Artista'
import ArtistaAdd from '@/components/ArtistaAdd'
import MusicoAdd from '@/components/MusicoAdd'

import Album from '@/components/Album'
import Albums from '@/components/Albums'
import Login from '@/components/Login'
import Cadastro from '@/components/Cadastro'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'artistas',
      component: HelloWorld
    },
    {
      path: '/artistas/add',
      name: 'artista-add',
      component: ArtistaAdd
    },
    {
      path: '/musicos/add',
      name: 'musico-add',
      component: MusicoAdd
    },
    {
      path: '/artistas/:id',
      name: 'artista',
      component: Artista,
      props: true
    },
    {
      path: '/album/:id',
      name: 'album',
      component: Album,
      props: true
    },
    {
      path: '/albums/',
      name: 'albums',
      component: Albums
    },
    {
      path: '/cadastro/',
      name: 'cadastro',
      component: Cadastro
    },
    {
      path: '/entrar/',
      name: 'login',
      component: Login,
      props: true
    }
  ]
})
