<template>
    <div>
        <span class="md-title">{{ album.title }} - {{ album.year  | moment("YYYY")}}</span>
        <md-table v-model="musicas" md-sort="title" md-sort-order="asc">
            <md-table-toolbar>
                <div class="md-toolbar-section-start">
                    <h1 class="md-title">Faixas</h1>
                </div>

            </md-table-toolbar>
            <md-table-empty-state
                    md-label="Nenhuma Faixa Encontrado"
                    :md-description="`Nenhuma faixa encontrado.`">
            </md-table-empty-state>
            <md-table-row slot="md-table-row" slot-scope="{ item }">
                <md-table-cell md-label="Ordem" md-sort-by="id" md-numeric>{{ item.number }}</md-table-cell>
                <md-table-cell md-label="Artista" md-sort-by="name">{{ item.name }}</md-table-cell>
                <md-table-cell md-label="Duração" md-sort-by="length">{{ item.length | moment("mm:ss") }}</md-table-cell>
            </md-table-row>
        </md-table>

        <div id="reviews" style="margin-top: 10px">
            <div class="md-toolbar-section-start">
                <h1 class="md-title">Reviews</h1>
                <h1 class="md-headline" style="margin-left: 50px"><a href="#reviews">Novo Review</a></h1>
            </div>
            <md-table v-model="reviews" md-sort="title" md-sort-order="asc">
                <md-table-empty-state
                        md-label="Nenhum review Encontrado"
                        :md-description="`Nenhuma review encontrado.`">
                </md-table-empty-state>
                <md-table-row slot="md-table-row" slot-scope="{ item }">
                    <md-table-cell md-label="Ranking" md-sort-by="user" md-numeric>{{ item.rank }}/10</md-table-cell>
                    <md-table-cell md-label="Usuario" md-sort-by="first_name">{{ item.user.first_name }}</md-table-cell>
                    <md-table-cell md-label="Review" md-sort-by="review">{{ item.review }}</md-table-cell>
                    <md-table-cell v-if="currentUser === item.user.id" md-numeric="">
                        <md-button @click="apagar(item.id)" class="md-raised md-primary">Editar</md-button>
                        <md-button @click="apagar(item.id)" class="md-raised md-accent">Apagar</md-button>
                    </md-table-cell>
                    <md-table-cell v-else md-numeric=""></md-table-cell>
                </md-table-row>
            </md-table>
        </div>
    </div>
</template>

<script>

export default {
  name: 'TableSearch',
  props: ['id'],
  computed: {
    getId: function () {
      if (this.id != null) {
        return this.id
      }
    }
  },
  data: () => ({
    currentUser: false,
    album: {},
    musicas: [],
    reviews: []
  }),
  methods: {
    apagar (id) {
      return id
    },
    loadArtista: function () {
      this.$http.get('http://localhost:8000/albums/' + this.getId).then((response) => {
        this.album = response.data
        this.musicas = this.album.album_tracks
        this.reviews = this.album.album_reviews
        console.log(this.album)
      }, (err) => {
        console.log(err)
      })
    }
  },
  mounted () {
    if (this.$root.logado) {
      this.current_user = localStorage.getItem('current_user')
    }
    this.loadArtista()
  }
}
</script>
